package com.example.toanyone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToAnyoneApplicationTests {

    @Test
    void contextLoads() {
    }

}
