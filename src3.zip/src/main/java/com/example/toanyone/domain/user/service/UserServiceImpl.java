package com.example.toanyone.domain.user.service;

public class UserServiceImpl {

}
