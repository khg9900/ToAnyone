package com.example.toanyone.global.common.code;

import com.example.toanyone.global.common.dto.ReasonDto;

public interface BaseCode {
    ReasonDto getReason();
    ReasonDto getReasonHttpStatus();
}
