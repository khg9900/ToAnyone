package com.example.toanyone.domain.reply.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;



@Getter
@AllArgsConstructor
public class ReplyResponseDto {
    private String message;
}
