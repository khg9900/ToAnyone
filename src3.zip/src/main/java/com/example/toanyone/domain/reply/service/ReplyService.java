package com.example.toanyone.domain.reply.service;

public interface ReplyService {

}
