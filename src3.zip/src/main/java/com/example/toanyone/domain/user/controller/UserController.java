package com.example.toanyone.domain.user.controller;

public class UserController {

}
