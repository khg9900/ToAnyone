package com.example.toanyone.domain.user.service;

public interface UserService {

}
